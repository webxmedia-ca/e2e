let username = "EASASU.T@gov.ab.ca";
let password = "FallWinter2018";

chrome.webRequest.onAuthRequired.addListener(
    function handler(details) {
        if (username == null)
            return {cancel: true};

        const authCredentials = {username:username, password: username};
        username = password = null;

        return {authCredentials: authCredentials};
    },
    {urls: ["<all_urls>"]},
    ['blocking']
);